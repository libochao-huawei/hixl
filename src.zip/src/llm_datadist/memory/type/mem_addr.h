/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef H0B406730_0930_4CFC_AA2F_77C264F2D4B1
#define H0B406730_0930_4CFC_AA2F_77C264F2D4B1

#include <cstdint>
#include "ge/ge_allocator.h"

namespace llm {
using MemAddr = uint8_t *;
using BlockAddr = ge::MemBlock *;
}

#endif
