/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include "adxl/adxl_engine.h"
#include <mutex>
#include <string>
#include "adxl/adxl_inner_engine.h"
#include "base/err_msg.h"
#include "adxl/fabric_mem_transfer_service.h"
#include "adxl/adxl_checker.h"
#include "engine/engine_factory.h"
#include "engine/engine.h"

namespace adxl {
namespace {
hixl::MemDesc ToHixlMemDesc(const MemDesc &mem) {
  return hixl::MemDesc{mem.addr, mem.len};
}

hixl::TransferOp ToHixlTransferOp(TransferOp operation) {
  return static_cast<hixl::TransferOp>(operation);
}

std::vector<hixl::TransferOpDesc> ToHixlTransferOpDescs(const std::vector<TransferOpDesc> &op_descs) {
  std::vector<hixl::TransferOpDesc> hixl_op_descs;
  hixl_op_descs.reserve(op_descs.size());
  for (const auto &desc : op_descs) {
    hixl_op_descs.emplace_back(hixl::TransferOpDesc{desc.local_addr, desc.remote_addr, desc.len});
  }
  return hixl_op_descs;
}

Status ToHixlTransferArgs(const TransferArgs &optional_args, hixl::TransferArgs &hixl_args) {
  auto ret = memcpy_s(&hixl_args, sizeof(hixl_args), &optional_args, sizeof(optional_args));
  ADXL_CHK_BOOL_RET_STATUS(ret == EOK, FAILED, "Failed to copy TransferArgs, memcpy_s returned:%d", ret);
  return SUCCESS;
}

hixl::NotifyDesc ToHixlNotifyDesc(const NotifyDesc &notify) {
  return hixl::NotifyDesc{notify.name, notify.notify_msg};
}

Status CheckTransferOpDescs(const std::vector<TransferOpDesc> &op_descs) {
  for (const auto &desc : op_descs) {
    auto local_addr = reinterpret_cast<void *>(desc.local_addr);
    auto remote_addr = reinterpret_cast<void *>(desc.remote_addr);
    ADXL_CHK_BOOL_RET_STATUS(local_addr != nullptr,
                             PARAM_INVALID, "local addr of desc can not be null.");
    ADXL_CHK_BOOL_RET_STATUS(remote_addr != nullptr,
                             PARAM_INVALID, "remote addr of desc can not be null.");
  }
  return SUCCESS;
}
}  // namespace

class AdxlEngine::AdxlEngineImpl {
 public:
  explicit AdxlEngineImpl(const AscendString &local_engine) : local_engine_(local_engine.GetString()) {}
  ~AdxlEngineImpl() = default;

  Status Initialize(const std::map<AscendString, AscendString> &options);

  void Finalize();

  Status RegisterMem(const MemDesc &mem, MemType type, MemHandle &mem_handle);

  Status DeregisterMem(MemHandle mem_handle);

  Status Connect(const AscendString &remote_engine, int32_t timeout_in_millis = 1000);

  Status Disconnect(const AscendString &remote_engine, int32_t timeout_in_millis = 1000);

  Status TransferSync(const AscendString &remote_engine,
                      TransferOp operation,
                      const std::vector<TransferOpDesc> &op_descs,
                      int32_t timeout_in_millis = 1000);

  Status TransferAsync(const AscendString &remote_engine,
                       TransferOp operation,
                       const std::vector<TransferOpDesc> &op_descs,
                       const TransferArgs &optional_args,
                       TransferReq &req);

  Status GetTransferStatus(const TransferReq &req, TransferStatus &status);

  Status SendNotify(const AscendString &remote_engine, const NotifyDesc &notify, int32_t timeout_in_millis);

  Status GetNotifies(std::vector<NotifyDesc> &notifies);

 private:
  std::mutex mutex_;
  std::string local_engine_;
  std::unique_ptr<hixl::Engine> engine_;
};

Status AdxlEngine::AdxlEngineImpl::Initialize(const std::map<AscendString, AscendString> &options) {
  std::lock_guard<std::mutex> lk(mutex_);
  if (engine_ != nullptr) {
    ADXL_CHK_BOOL_RET_SPECIAL_STATUS(engine_->IsInitialized(), SUCCESS, "Already initialized");
  }
  engine_ = hixl::EngineFactory::CreateEngine(local_engine_, options);
  ADXL_CHECK_NOTNULL(engine_, "Failed to create engine, local_engine:%s", local_engine_.c_str());
  ADXL_CHK_STATUS_RET(engine_->Initialize(options), "Failed to initialize AdxlEngine.");
  return SUCCESS;
}

void AdxlEngine::AdxlEngineImpl::Finalize() {
  if (engine_ != nullptr) {
    engine_->Finalize();
  }
}

Status AdxlEngine::AdxlEngineImpl::RegisterMem(const MemDesc &mem, MemType type, MemHandle &mem_handle) {
  ADXL_CHK_BOOL_RET_STATUS(engine_ != nullptr && engine_->IsInitialized(), FAILED, "AdxlEngine is not initialized");
  ADXL_CHK_BOOL_RET_STATUS(reinterpret_cast<void *>(mem.addr) != nullptr,
                           PARAM_INVALID, "mem.addr can not be null");
  ADXL_CHK_STATUS_RET(engine_->RegisterMem(ToHixlMemDesc(mem), static_cast<hixl::MemType>(type), mem_handle),
                      "Failed to register mem");
  return SUCCESS;
}

Status AdxlEngine::AdxlEngineImpl::DeregisterMem(MemHandle mem_handle) {
  ADXL_CHK_BOOL_RET_STATUS(engine_ != nullptr && engine_->IsInitialized(), FAILED, "AdxlEngine is not initialized");
  ADXL_CHK_BOOL_RET_STATUS(mem_handle != nullptr, PARAM_INVALID, "mem_handle can not be null");
  ADXL_CHK_STATUS_RET(engine_->DeregisterMem(mem_handle), "Failed to deregister mem");
  return SUCCESS;
}

Status AdxlEngine::AdxlEngineImpl::Connect(const AscendString &remote_engine, int32_t timeout_in_millis) {
  ADXL_CHK_BOOL_RET_STATUS(engine_ != nullptr && engine_->IsInitialized(), FAILED, "AdxlEngine is not initialized");
  ADXL_CHK_STATUS_RET(engine_->Connect(remote_engine, timeout_in_millis), "Failed to connect");
  return SUCCESS;
}

Status AdxlEngine::AdxlEngineImpl::Disconnect(const AscendString &remote_engine, int32_t timeout_in_millis) {
  ADXL_CHK_BOOL_RET_STATUS(engine_ != nullptr && engine_->IsInitialized(), FAILED, "AdxlEngine is not initialized");
  ADXL_CHK_STATUS_RET(engine_->Disconnect(remote_engine, timeout_in_millis), "Failed to disconnect");
  return SUCCESS;
}

Status AdxlEngine::AdxlEngineImpl::TransferSync(const AscendString &remote_engine,
                                                TransferOp operation,
                                                const std::vector<TransferOpDesc> &op_descs,
                                                int32_t timeout_in_millis) {
  ADXL_CHK_BOOL_RET_STATUS(engine_ != nullptr && engine_->IsInitialized(), FAILED, "AdxlEngine is not initialized");
  ADXL_CHK_STATUS_RET(CheckTransferOpDescs(op_descs), "Failed to check transfer op descs");
  ADXL_CHK_STATUS_RET(engine_->TransferSync(remote_engine, ToHixlTransferOp(operation),
                                            ToHixlTransferOpDescs(op_descs), timeout_in_millis),
                      "Failed to transfer sync.");
  return SUCCESS;
}

Status AdxlEngine::AdxlEngineImpl::TransferAsync(const AscendString &remote_engine,
                                                 TransferOp operation,
                                                 const std::vector<TransferOpDesc> &op_descs,
                                                 const TransferArgs &optional_args,
                                                 TransferReq &req) {
  ADXL_CHK_BOOL_RET_STATUS(engine_ != nullptr && engine_->IsInitialized(), FAILED, "AdxlEngine is not initialized.");
  ADXL_CHK_STATUS_RET(CheckTransferOpDescs(op_descs), "Failed to check transfer op descs.");
  hixl::TransferArgs hixl_args;
  ADXL_CHK_STATUS_RET(ToHixlTransferArgs(optional_args, hixl_args), "Failed to convert TransferArgs.");
  ADXL_CHK_STATUS_RET(engine_->TransferAsync(remote_engine, ToHixlTransferOp(operation),
                                             ToHixlTransferOpDescs(op_descs), hixl_args, req),
                      "Failed to transfer async.");
  return SUCCESS;
}

Status AdxlEngine::AdxlEngineImpl::GetTransferStatus(const TransferReq &req, TransferStatus &status) {
  hixl::TransferStatus transfer_status = hixl::TransferStatus::WAITING;
  auto ret = engine_->GetTransferStatus(req, transfer_status);
  if (ret != SUCCESS) {
    status = TransferStatus::FAILED;
    LLMLOGE(ret, "Failed to get transfer request status.");
    return ret;
  }
  status = static_cast<TransferStatus>(transfer_status);
  return SUCCESS;
}

Status AdxlEngine::AdxlEngineImpl::SendNotify(const AscendString &remote_engine, const NotifyDesc &notify, int32_t timeout_in_millis) {
  ADXL_CHK_BOOL_RET_STATUS(engine_ != nullptr && engine_->IsInitialized(), FAILED, "AdxlEngine is not initialized");
  ADXL_CHK_STATUS_RET(engine_->SendNotify(remote_engine, ToHixlNotifyDesc(notify), timeout_in_millis),
                      "Failed to send notify to remote engine:%s", remote_engine.GetString());
  return SUCCESS;
}

Status AdxlEngine::AdxlEngineImpl::GetNotifies(std::vector<NotifyDesc> &notifies) {
  ADXL_CHK_BOOL_RET_STATUS(engine_ != nullptr && engine_->IsInitialized(), FAILED, "AdxlEngine is not initialized");
  std::vector<hixl::NotifyDesc> hixl_notifies;
  ADXL_CHK_STATUS_RET(engine_->GetNotifies(hixl_notifies), "Failed to get notifies");
  notifies.reserve(notifies.size() + hixl_notifies.size());
  for (const auto &notify : hixl_notifies) {
    notifies.emplace_back(NotifyDesc{notify.name, notify.notify_msg});
  }
  return SUCCESS;
}

AdxlEngine::AdxlEngine() {}

AdxlEngine::~AdxlEngine() {
  Finalize();
}

Status AdxlEngine::Initialize(const AscendString &local_engine, const std::map<AscendString, AscendString> &options) {
  LLMLOGI("AdxlEngine initialize start");
  impl_ = llm::MakeUnique<AdxlEngineImpl>(local_engine);
  ADXL_CHK_BOOL_RET_STATUS(impl_ != nullptr, FAILED, "impl is nullptr, check AdxlEngine construct");
  const auto ret = impl_->Initialize(options);
  ADXL_CHK_BOOL_RET_STATUS(ret == SUCCESS, ret, "Failed to initialize AdxlEngine");
  LLMLOGI("AdxlEngine initialized successfully");
  return SUCCESS;
}

void AdxlEngine::Finalize() {
  LLMLOGI("AdxlEngine finalize start");
  if (impl_ != nullptr) {
    impl_->Finalize();
    impl_.reset();
  }
  LLMLOGI("AdxlEngine finalized successfully");
}

Status AdxlEngine::RegisterMem(const MemDesc &mem, MemType type, MemHandle &mem_handle) {
  LLMLOGI("RegisterMem start, type:%d, addr:%p, size:%zu",
         static_cast<int32_t>(type), reinterpret_cast<void *>(mem.addr), mem.len);
  ADXL_CHK_BOOL_RET_STATUS(impl_ != nullptr, FAILED, "impl is nullptr, check AdxlEngine init");
  const auto ret = impl_->RegisterMem(mem, type, mem_handle);
  ADXL_CHK_BOOL_RET_STATUS(ret == SUCCESS, ret, "Failed to register mem, "
                           "type:%d, addr:%p, size:%lu",
                           static_cast<int32_t>(type), reinterpret_cast<void *>(mem.addr), mem.len);
  LLMLOGI("RegisterMem success, type:%d, addr:%p, size:%zu, handle:%p",
         static_cast<int32_t>(type), reinterpret_cast<void *>(mem.addr), mem.len, mem_handle);
  return SUCCESS;
}

Status AdxlEngine::DeregisterMem(MemHandle mem_handle) {
  LLMLOGI("DeregisterMem start, mem_handle:%p", mem_handle);
  ADXL_CHK_BOOL_RET_STATUS(impl_ != nullptr, FAILED, "impl is nullptr, check AdxlEngine init");
  const auto ret = impl_->DeregisterMem(mem_handle);
  ADXL_CHK_BOOL_RET_STATUS(ret == SUCCESS, ret, "Failed to deregister mem, mem_handle:%p",
                           mem_handle);
  LLMLOGI("DeregisterMem success, mem_handle:%p", mem_handle);
  return SUCCESS;
}

Status AdxlEngine::Connect(const AscendString &remote_engine, int32_t timeout_in_millis) {
  LLMLOGI("Connect start, remote engine:%s, timeout:%d ms", remote_engine.GetString(), timeout_in_millis);
  ADXL_CHK_BOOL_RET_STATUS(impl_ != nullptr, FAILED, "impl is nullptr, check AdxlEngine init");
  ADXL_CHK_BOOL_RET_STATUS(timeout_in_millis > 0, PARAM_INVALID, "timeout_in_millis:%d must > 0", timeout_in_millis);
  const auto ret = impl_->Connect(remote_engine, timeout_in_millis);
  ADXL_CHK_BOOL_RET_STATUS(ret == SUCCESS, ret,
                           "Failed to connect, remote engine:%s, timeout:%d ms",
                           remote_engine.GetString(), timeout_in_millis);
  LLMLOGI("Connect success, remote engine:%s, timeout:%d ms", remote_engine.GetString(), timeout_in_millis);
  return SUCCESS;
}

Status AdxlEngine::Disconnect(const AscendString &remote_engine, int32_t timeout_in_millis) {
  LLMLOGI("Disconnect start, remote engine:%s, timeout:%d ms", remote_engine.GetString(), timeout_in_millis);
  ADXL_CHK_BOOL_RET_STATUS(impl_ != nullptr, FAILED, "impl is nullptr, check AdxlEngine init");
  ADXL_CHK_BOOL_RET_STATUS(timeout_in_millis > 0, PARAM_INVALID, "timeout_in_millis:%d must > 0", timeout_in_millis);
  const auto ret = impl_->Disconnect(remote_engine, timeout_in_millis);
  ADXL_CHK_BOOL_RET_STATUS(ret == SUCCESS, ret,
                           "Failed to disconnect, remote engine:%s, timeout:%d ms",
                           remote_engine.GetString(), timeout_in_millis);
  LLMLOGI("Disconnect success, remote engine:%s, timeout:%d ms", remote_engine.GetString(), timeout_in_millis);
  return SUCCESS;
}

Status AdxlEngine::TransferSync(const AscendString &remote_engine,
                                TransferOp operation,
                                const std::vector<TransferOpDesc> &op_descs,
                                int32_t timeout_in_millis) {
  auto start = std::chrono::steady_clock::now();
  LLMLOGI("TransferSync start, remote_engine:%s, operation:%s, op_descs size:%zu, timeout:%d ms",
          remote_engine.GetString(), hixl::TransferOpToString(static_cast<hixl::TransferOp>(operation)).c_str(),
          op_descs.size(), timeout_in_millis);
  ADXL_CHK_BOOL_RET_STATUS(impl_ != nullptr, FAILED, "impl is nullptr, check AdxlEngine init");
  ADXL_CHK_BOOL_RET_STATUS(timeout_in_millis > 0, PARAM_INVALID, "timeout_in_millis:%d must > 0", timeout_in_millis);
  ADXL_CHK_STATUS_RET(impl_->TransferSync(remote_engine, operation, op_descs, timeout_in_millis),
                      "Failed to TransferSync, remote_engine:%s, operation:%s, op_descs size:%zu, timeout:%d ms",
                      remote_engine.GetString(),
                      hixl::TransferOpToString(static_cast<hixl::TransferOp>(operation)).c_str(), op_descs.size(),
                      timeout_in_millis);
  LLMLOGI("TransferSync success, remote_engine:%s, operation:%s, op_descs size:%zu, cost time: %ld us.",
          remote_engine.GetString(), hixl::TransferOpToString(static_cast<hixl::TransferOp>(operation)).c_str(),
          op_descs.size(),
          std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - start).count());
  return SUCCESS;
}
Status AdxlEngine::TransferAsync(const AscendString &remote_engine,
                                 TransferOp operation,
                                 const std::vector<TransferOpDesc> &op_descs,
                                 const TransferArgs &optional_args,
                                 TransferReq &req) {
  ADXL_CHK_BOOL_RET_STATUS(impl_ != nullptr, FAILED, "Impl is nullptr, check Hixl init.");
  ADXL_CHK_STATUS_RET(impl_->TransferAsync(remote_engine, operation, op_descs, optional_args, req),
                      "Failed to transfer async, remote_engine:%s, operation:%s, op_descs size:%zu.",
                      remote_engine.GetString(),
                      hixl::TransferOpToString(static_cast<hixl::TransferOp>(operation)).c_str(), op_descs.size());
  LLMLOGI("Transfer async success, remote_engine:%s, operation:%s, op_descs size:%zu.", remote_engine.GetString(),
          hixl::TransferOpToString(static_cast<hixl::TransferOp>(operation)).c_str(), op_descs.size());
  return SUCCESS;
}

Status AdxlEngine::GetTransferStatus(const TransferReq &req, TransferStatus &status) {
  ADXL_CHK_BOOL_RET_STATUS(req != nullptr, FAILED, "Req is nullptr, check req.");
  ADXL_CHK_STATUS_RET(impl_->GetTransferStatus(req, status),
                      "Failed to get transfer status, req:%llu.", 
                      static_cast<unsigned long long>(reinterpret_cast<uintptr_t>(req)));
  return SUCCESS;
}

Status AdxlEngine::SendNotify(const AscendString &remote_engine, const NotifyDesc &notify, int32_t timeout_in_millis) {
  LLMLOGI("SendNotify start, remote engine:%s, notify name:%s", remote_engine.GetString(), notify.name.GetString());
  ADXL_CHK_BOOL_RET_STATUS(impl_ != nullptr, FAILED, "impl is nullptr, check AdxlEngine init");
  constexpr uint32_t kMaxNotifyLength = 1024U;
  ADXL_CHK_BOOL_RET_STATUS(notify.name.GetLength() <= kMaxNotifyLength, PARAM_INVALID,
                           "notify.name length exceed max limit: %u, current: %zu", kMaxNotifyLength, notify.name.GetLength());
  ADXL_CHK_BOOL_RET_STATUS(notify.notify_msg.GetLength() <= kMaxNotifyLength, PARAM_INVALID,
                           "notify.notify_msg length exceed max limit: %u, current: %zu", kMaxNotifyLength, notify.notify_msg.GetLength());
  ADXL_CHK_BOOL_RET_STATUS(timeout_in_millis > 0, PARAM_INVALID, "timeout_in_millis:%d must > 0", timeout_in_millis);
  const auto ret = impl_->SendNotify(remote_engine, notify, timeout_in_millis);
  
  ADXL_CHK_BOOL_RET_STATUS(ret == SUCCESS, ret,
                           "Failed to send notify, remote engine:%s, notify name:%s",
                           remote_engine.GetString(), notify.name.GetString());
  LLMLOGI("SendNotify success, remote engine:%s, notify name:%s", remote_engine.GetString(), notify.name.GetString());
  return SUCCESS;
}

Status AdxlEngine::GetNotifies(std::vector<NotifyDesc> &notifies) {
  LLMLOGI("GetNotifies start");
  ADXL_CHK_BOOL_RET_STATUS(impl_ != nullptr, FAILED, "impl is nullptr, check AdxlEngine init");
  
  const auto ret = impl_->GetNotifies(notifies);
  
  ADXL_CHK_BOOL_RET_STATUS(ret == SUCCESS, ret,
                           "Failed to get notifies");
  LLMLOGI("GetNotifies success, got %zu notifies", notifies.size());
  return SUCCESS;
}

Status AdxlEngine::MallocMem(MemType type, size_t size, void **ptr) {
  return FabricMemTransferService::MallocMem(type, size, ptr);
}

Status AdxlEngine::FreeMem(void *ptr) {
  return FabricMemTransferService::FreeMem(ptr);
}

} // namespace adxl
